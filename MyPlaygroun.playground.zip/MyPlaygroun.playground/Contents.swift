import UIKit

var greeting = "Hello, playground"

print ("Hello all,\r Welcome to Swift programming")


print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "*" )
print("Fall 2021")


print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "*")


print(10,20,30)
    print(12.5,15.5)

      print(4 > 5 && 8 > 3)

print(5 > 7 || 8 < 2 * 5)

print (!(5 <= 4 || 6 != 5 && 10 >= 4))
print("_______")
var number1 = (3,4)
var number2 = (3,5)
print(number1 <  number2 )


var inputNumber = -10
if inputNumber>0 {
    print("\(inputNumber) is a positive number.")
}else if (inputNumber<0){
    print("\(inputNumber) is a negative number")
    if(inputNumber%2==0){
        print("\(inputNumber) is a negative even number")
    }
}else {
    print("The number  is 0")
}

var stars = 65
if(stars>=90) {
print("You are a Pro Member")
}
else if (stars<=78 && stars<90){
print("You are a Gold Member")
}
else if (stars>=65 && stars<78) {
    print("You are a VIP Member")
}

var password:String="stephen@171"
if(password.count>8){
    if(password.contains(" ")){
       print("Password Should not contain space")
    }
    else{
    print("Password is Strong")
    }
}
else
{
   print("A password should be minimum of 8 characters")
   }

var male:Bool=false
var age = 45
if male {
    if age<20 {
        print("BOY")
    }else {
        print("MAN")
    }
}else{
    if age<20{
        print("Girl")
    }else{
        print("Woman")
    }
}

var httpError  = (errorCode : 404  , errorMessage : "PageNot Found")
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )


var origin = (x : 0 , y : 0)
var point = origin
print(point)


var fact = "Swift is a type safe language"
var dev = "Development of Swift began in 2010"
var author = "Swift was created by Chris Lattner"

print(fact.count)
print(dev.append(" by Apple"))
print(dev)

print(author.lowercased())

print(author.uppercased())

print(author[author.startIndex])

print(author[author.index(before: author.endIndex)])


print(author[author.index(after: author.startIndex)])

print(author[author.index(author.startIndex,offsetBy: 6)])


print(author[author.index(author.endIndex,offsetBy: -6)])

print(fact[fact.index(fact.endIndex,offsetBy: -4)])
